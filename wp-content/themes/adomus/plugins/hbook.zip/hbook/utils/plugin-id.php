<?php
class HbPluginId {

	public function get_id() {
		return 'tf-hbook-v1.6-2016-09-25';
	}
	
}