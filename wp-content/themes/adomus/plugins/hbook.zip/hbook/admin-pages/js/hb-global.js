jQuery( document ).ready( function( $ ) {
   
    $( '.wp-first-item a[href="admin.php?page=hb_menu"]' ).parent().remove();
    
});